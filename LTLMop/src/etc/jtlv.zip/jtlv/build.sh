#!/bin/sh
cd GROne
javac -sourcepath . -cp ../jtlv-prompt1.4.0.jar *.java

